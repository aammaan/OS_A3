#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
pthread_t philo[5];
sem_t fock[5];


void eat_permission1(int i){
    printf("\033[0;36mPhilosopher %d is thinknig\n\n",i+1);
    printf("\033[0;32mPhilosopher %d started eating\n\n",i+1);
    sleep(2);
    printf("\033[0;33mPhilosopher %d just finished eating\n\033[0m\n\n",i+1);
}
void eat_permission(int i){
    printf("\033[0;36mPhilosopher %d is thinknig\n\n",i+1);
    sem_wait(&fock[i]);
    sem_wait(&fock[(i+1)%5]);
    printf("\033[0;32mPhilosopher %d started eating\n\n",i+1);
    sleep(2);
    printf("\033[0;33mPhilosopher %d just finished eating\n\033[0m\n\n",i+1);

    sem_post(&fock[(i+1)%5]);
    sem_post(&fock[i]);
}

int main(){

    int inp=0;
    printf("Choose how do you wanna solve the probelm:\n1) Strict ordering of resource requests,\n2) Utilization of semaphores to access the resources\n");
    scanf("%d",&inp);
    if(inp==1){
        while(1){
            int k=0;
            void *retur;
            //thread for philos
            while(k<5){
                int check1 = pthread_create(&philo[k],NULL,(void*)eat_permission1,(int *)k);
                if(check1 !=0){
                    printf("Error in creating Pthread");
                    exit(0);
                }
                int check2 = pthread_join(philo[k],&retur);
                if(check2 !=0){
                    printf("Error in joining Pthread");
                    exit(0);
                }
                k++;
            }
        }
    }else if(inp==2){
        while(1){
            int i;
            //Here we are making a array which contain all the semaphores.
            while(i<5){
                int check = sem_init(&fock[i],0,1);
                if(check ==-1){
                    printf("Error in creating mutex");
                    exit(0);
                }
                i++;
            }
            int k=0;
            //thread for philos
            while(k<5){
                int check1 = pthread_create(&philo[k],NULL,(void*)eat_permission,(int *)k);
                if(check1 !=0){
                    printf("Error in creating Pthread");
                    exit(0);
                }
                k++;
            }
            //thread joining
            void *retur;
            int l=0;
            while(l<5){
                int check2 = pthread_join(philo[l],&retur);
                if(check2 !=0){
                    printf("Error in joining Pthread");
                    exit(0);
                }
                l++;
            }
            int m=0;
            //destroying mutexes
            while(m<5){
                int check3 = pthread_mutex_destroy(&fock[m]);
                if(check3 !=0){
                    printf("Error in destroying mutex");
                    exit(0);
                }
                m++;
            }
        }
    }
    return 0;

}