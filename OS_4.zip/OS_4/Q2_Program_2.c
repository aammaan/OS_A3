#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include<sys/un.h>
#include<errno.h>
#include<sys/socket.h>
#include <sys/types.h>
#include<string.h>

struct pack{
    char data[6];
    int ID;
};

int main(int t1,char* t2){
    int len=6;
    int total=50;
    int cut=5;
    int check=0;

    printf("How would you like to share the data:\n1) UNIX DOMAIN SOCKET\n2) FIFO_PIPE\n3) SHARED MEMORY \n");
    scanf("%d",&check);
    if(check==1){
        int count1=0;
        int soc=socket(1,1,0);
        struct sockaddr_un program_1;
        program_1.sun_family = 1;
        strcpy(program_1.sun_path,"Server");
        
        unlink("Server");
        bind(soc,(struct sockaddr *) &program_1,sizeof(program_1));
        listen(soc,5);
        int to=sizeof(program_1);
        struct sockaddr_un program_2;
        int acpt=accept(soc,(struct sockaddr *) &program_2,&to);
        int too = sizeof(program_2);
        getpeername(acpt,(struct sockaddr *) &program_2,&too);

        printf("\033[0;36mGetting Data from Program 1 by Socket\n\n\n");
        struct pack collect1[cut];

        while(count1<total-cut){
            recv(acpt,&collect1,sizeof(struct pack)*cut,0);
            for(int n=0;n<cut;n++){
                printf("\033[0;34mID: %d & String: %s\n",collect1[n].ID,collect1[n].data);
                count1 = collect1[n].ID;

            }
            send(acpt,&count1,sizeof(count1),0);
            printf("\033[0;33mLast Index till now: %d\n\033[0m\n",count1);

        }

        close(soc);
        close(acpt);

        return 0;

    }else if(check==2){
        struct pack collect[cut];
        int count = 0;

        printf("\033[0;36mGetting Data from Program 1\n\n\n");

        while(count<total){
            int pip=open("Fpipe", 00);
            if(pip==-1){
                printf("\033[0;31m Error in creating Fifo_Pipe");
                exit(0);
            }

            read(pip,collect,sizeof(struct pack)*cut);
            for(int k=0;k<cut;k++){
                printf("\033[0;34mID: %d & String: %s\n",collect[k].ID,collect[k].data);
                
            }
            count = collect[cut-1].ID;
            close(pip);
            pip = open("Fpipe",01);
            write(pip,&count,sizeof(count));

            printf("\033[0;33mLast Index till now: %d\n\033[0m\n",count);
            close(pip);
            count++;
        }
        return 0;
    }
}
