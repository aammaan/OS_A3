#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <sys/types.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/un.h>

//function to create a random String
char *randm(){
    char *all="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    char *out=malloc(sizeof(char)*6);
    for(int i = 0;i<6;i++){
        int ranDom= rand()%42;
        out[i]=all[ranDom];
    }
    out[5]='\0';
    return out;
}
//struct to store data and Id 
struct pack{
    char data[6];
    int ID;
};

int main(int t1,char* t2){
    int len=6;
    int total=50;
    int cut=5;
    int check=0;
    // To make a array of random Strings
    srand(time(0));
    char *arr[total];
    for(int j =0;j<total;j++){
        arr[j]=randm();
    }

    //What would you like to use?

    printf("How would you like to share the data:\n1) UNIX DOMAIN SOCKET\n2) FIFO_PIPE\n3) SHARED MEMORY \n");
    scanf("%d",&check);
    if(check==1){
        int count1=0;
        int soc = socket(1,1,0);
        struct pack collect1[cut];

        struct sockaddr_un program_1;
        program_1.sun_family = 1;
        strcpy(program_1.sun_path,"Server");

        struct sockaddr_un program_2;
        program_2.sun_family =1;
        strcpy(program_2.sun_path,"Client");

        bind(soc,(struct sockaddr *) &program_2,sizeof(program_2));
        connect(soc,(struct sockaddr *)&program_1,sizeof(program_2));
        printf("\033[0;36mTransfering data to Program 2 with Sockets\n\n\n");

        while(count1 < total){
            
            for(int m =0;m<cut;m++){
                memcpy(collect1[m].data,arr[m],sizeof(arr[m]));
                collect1[m].ID = m +count1;

            }
            send(soc,collect1,sizeof(struct pack)*cut,0);
            recv(soc,&count1,sizeof(count1),0);

            printf("\033[0;32mArray recieved till Index: %d\n\n\033[0m",count1);
            count1++;

        }
        close(soc);
        return 0;

    }else if(check ==2){
        
        struct pack collect[cut];
        int count = 0;
        
        //By using unlink we don't need to delete the earlier created PIPE.
        //This will unlink the previous PIPE.
        unlink("Fpipe");

        //Creating PIPE
        int op=mkfifo("Fpipe",0666);
        if(op==-1){
            printf("\033[0;31m Error in creating Fifo_Pipe");
            exit(0);
        }
        
        printf("\033[0;36mTransfering data to Program 2 with Fifo_Pipe\n\n\n");

        while(count<total){
            int pip=open("Fpipe", 01);
        
            for(int j =0;j<cut;j++){
                memcpy(collect[j].data,arr[j],sizeof(arr[j]));
                collect[j].ID = j + count;
            }
            if(pip==-1){
                printf("\033[0;31m Error in creating Fifo_Pipe");
                exit(0);
            }
            write(pip,collect,sizeof(struct pack)*cut);
            close(pip);
            pip = open("Fpipe",00);
            read(pip,&count,sizeof(count));
            close(pip);
            printf("\033[0;32mArray recieved till Index: %d\n\n\033[0m",count);
            count++;
        }
        return 0;
    }
}
