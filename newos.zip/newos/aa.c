#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/sched/signal.h>
#include<linux/cred.h>
#include<linux/sched.h>
#include<linux/pid.h>
#include<linux/proc fs.h>
#include<linux/cdev.h>
#include<linux/fs.h>
#include<linux/unaccess.h>
#include<linux/moduleparam.h>
#include<linux/stat.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("AMAN");
MODULE_DESCRIPTION("TASK STRUCT MODULE OS");

int p_id;
struct pid *PiD;
struct task_struct * task_struct;
int x= 3;
module_param(x,int,0);

static int __init Structur_init(void){
    PiD=find_get_pid(x);
    task_struct = pid_task(PiD,PIDTYPE_PID);    
    // pgid=pid_vrn(task_pgrp(task));
    printk(KERN_INFO "PID of process is %d\n",task->pid);
    printk(KERN_INFO "Process command is %s\n",task->comm);
    printk(KERN_INFO "process userID is %d\n",task->cred->uid.val);
    printk(KERN_INFO "group id of process is %d\n",task->cred->gid.val);
    // printk(KERN_NOTICE "user if of process is %d\n",task->pgid);
    // printf(KERN_NOTICE "group id of process is %d\n",task->gid);
    return 0;
    
}

static void __exit Structur_cleanup(void){
    printk(KERN_INFO "Reading complete \n","Done..!");

}

module_init(Structur_init);
module_exit(Structur_cleanup);