#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/sched.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("AMAN");
MODULE_DESCRIPTION("Task struct reading module");

static int __init Structure_init(void){
    struct task_struct *task =current;
    printf(KERN_NOTICE "PID of process is %d\n",task->pid);
    printf(KERN_NOTICE "user if of process is %d\n",task->uid);
    printf(KERN_NOTICE "group id of process is %d\n",task->gid);
    return 0;
    
}

static void __exit Structure_cleanup(void){
    printf(KERN_NOTICE "Reading complete \n",);

}

module __init(Structure_init);
module __exit(Structure_cleanup);