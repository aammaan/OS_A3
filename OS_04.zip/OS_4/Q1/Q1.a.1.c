#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
pthread_t philo[5];
sem_t fock[5];


void eat_permission1(int i){
    printf("\033[0;36mPhilosopher %d is thinknig\n\n",i+1);
    printf("\033[0;32mPhilosopher %d started eating\n\n",i+1);
    sleep(2);
    printf("\033[0;33mPhilosopher %d just finished eating\n\033[0m\n\n",i+1);
}

int main(){
    while(1){
        int k=0;
        void *retur;
        //thread for philos
        while(k<5){
            int check1 = pthread_create(&philo[k],NULL,(void*)eat_permission1,(int *)k);
            if(check1 !=0){
                printf("Error in creating Pthread");
                exit(0);
            }
            int check2 = pthread_join(philo[k],&retur);
            if(check2 !=0){
                printf("Error in joining Pthread");
                exit(0);
            }
            k++;
        }
    }
    
}