#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
pthread_t philo[5];
// sem_t fock[5];
int bowl=2;

void eat_permission(int i){
    int cho=0;
    while(cho==0){
        printf("\033[0;36mPhilosopher %d is thinking\n\n",i+1);
        if(bowl>0){
            bowl-=1;
        
            printf("\033[0;32mPhilosopher %d started eating\n\n",i+1);
            sleep(2);
            bowl+=1;
            printf("\033[0;33mPhilosopher %d just finished eating\n\033[0m\n\n",i+1);
        }
        cho=1;
    }
}

int main(){
    while(1){
        int k=0;
        void *retur;
        //thread for philos
        while(k<5){
            int check1 = pthread_create(&philo[k],NULL,(void*)eat_permission,(int *)k);
            int check2 = pthread_join(philo[k],&retur);

            if(check1 !=0){
                printf("Error in creating Pthread");
                exit(0);
            }
            k++;
        }
      
        
      
    }
    return 0;
}